<?php
session_start();
?>
<?php
$department=$_POST['department'];
echo "<b>THE LIST OF Faculties WHO HAVE OPTED FOR<br>"."$department"."<br></b>";

$dbc=mysqli_connect('localhost','root','123456','store') or die ("error connecting to the database");


$sql="select Slno,Fullname,ID,Department,Item_reuqired,quantity FROM form_request WHERE Department='$department' ";
$result=mysqli_query($dbc,$sql) or die("error querying");
?>
<style>
table, th, td{
border:1px solid black;
border-collapse: collapse;
}
th, td{
padding:15px;
}
</style>
<table border=1px>
<tr> 
      <tr>
<th>Slno</th>
<th>Fullname</th>
<th>ID</th>
<th>Department</th>
<th>Item Required</th>
<th>Quantity</th>
</tr>
<?php 
                 while($row=mysqli_fetch_array($result))
                 {  

            ?>
              <td><?php echo $row['Slno'];?></td> 
	      <td><?php echo $row['Fullname'];?></td> 
              <td><?php echo $row['ID'];?></td> 
	      <td><?php echo $row['Department'];?></td> 
	      <td><?php echo $row['Item_reuqired'];?></td> 
	      <td><?php echo $row['quantity'];?></td> 
	      
                          </tr>



           <?php } ?>
</table>
<a href="request.php">Back</a>
<?php
mysqli_close($dbc);
?>
