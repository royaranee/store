<?php
session_start();
?>
<html>
<head>
<title>Request details</title>
<head>
<body>
<!
To verify whether the admin logged in
--if($_SESSION['logged_in'] !=1)


-->
<style>
table, th, td{
border:1px solid black;
border-collapse: collapse;
}
th, td{
padding:15px;
}
</style>
<?php

$dbc=mysqli_connect('localhost','root','123456','store')or die('Error connecting to the database');
$query ="select *from form_request ORDER BY Slno DESC";
$result=mysqli_query($dbc,$query)or die('error querying the database for selection');
$row=mysqli_fetch_array($result);


?>
<h1>Welcome Admin !!!</h1>
<h2>Faculties who have requested items through online</h2>
<form method="POST" action="manager.php">
<input type="submit" value= "Back" align="right" name="back" ></br></br>
</form>
<form method="POST" action="search1.php">
course:<select name="department">
<option value="">select</option>
<option value="CSE">CSE</option> 
<option value="EEE">EEE</option>
<option value="ECE">ECE</option>
<option value="MEE">MEE</option>
<option value="CVE">CVE</option>
<option value="PEE">PEE</option>
</select>
<input type="submit"  name="search" value="search">
</form>

<table border=1px>
<tr>
<th>Slno</th>
<th>Fullname</th>
<th>ID</th>
<th>Department</th>
<th>Item Required</th>
<th>Quantity</th>
</tr> 
<tr>
<?php 
                 while($row=mysqli_fetch_array($result))
                 {  

            ?>
              <td><?php echo $row['Slno'];?></td> 
	      <td><?php echo $row['Fullname'];?></td> 
              <td><?php echo $row['ID'];?></td> 
	      <td><?php echo $row['Department'];?></td> 
	      <td><?php echo $row['Item_reuqired'];?></td> 
	      <td><?php echo $row['quantity'];?></td>
                          </tr>



           <?php } ?>
</tr>
</table>
</body>
</html>

