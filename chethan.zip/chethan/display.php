<!DOCTYPE html>
<?php
include 'connect.php';
$query = "select *from items";
$result = mysqli_query($con,$query);
?>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}
.error {color: #FF0000;}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
 text-align:center;
background-image:url("bgcover1.jpg");
background-repeat:no-repeat;
background-size: 1400px 1000px;
margin:0;

}
 div.container {
 border:1px solid black;
    width:80%; 
    margin:1%;
    position: auto;
  
    left:8%;
    background-color:white;
  }
  img {vertical-align: middle;
width:70%;
height:70%;}
  .lol
{
 border:2px solid black;
    width:30%;
    height:50%; 
    margin:1%;
   position: auto;
   align:center;
   }

  </style>
  </head>
<body>
<div class="container">
<h1>GIFT ITEMS</h1>
<table width="auto" bgcolor="white"  align="center" border="1px">
<th colspan="2">ITEMS</th>
<th>PRICE</th>
<th>SELECT</th>
		
		
	<?php while($row = mysqli_fetch_array($result)){?>
	<tr border="1px solid">
			
		<td align="center" width="50%" > 
		<div class="lol">
			<?php $image= $row['userfile'] ;
			 $img="uploads/".$image;
			 echo'<img src="'.$img.'" width="20%" height="20%">';?>  </div></td>
			 
		<td> <?php echo $row['category'] ?></td>
		<td> <?php echo $row['price']?></td>
		<td> <form action="/action_page.php">
  <input type="checkbox" name="<?php $image?>">
 

</td>
   </tr>
    
				<?php } ?>
				</table>
				</br>
				</br>
				  <input type="submit" value="Submit">
</form> 
</br>
</br>
		</div>
					
		
		
		</body>
		</html>
		
		
