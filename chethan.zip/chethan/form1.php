<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  text-align:center;
background-image:url("bgstore.jpg");
background-repeat:no-repeat;
background-size: 1400px 1500px;
margin:0;
}

.topnav {
  overflow: hidden;
  background-color: #F00000;
   position: auto;
    width: 100%;
}

.topnav a {
  float: right;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #111111;
  color: white;
}

.topnav a.active {
  background-color: #F00000;
  color: white;
}

.topnav .search-container {
  position:absolute;
    left:11%;
    top:34%;
    width:auto;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;
width:20%;
height:20%;}

/* Slideshow container */
.slideshow-container {
  max-width: 2000px;
  position: auto;
 
  margin: auto;
}
.slideshow-container img {
  max-width:100%;
	width:100%;
	height: 60%;
	position:auto;
	left:0;
	
  }
/* Caption text */
.text {
  color: black;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: black;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 10px;
  width: 10px;
  position:fixed;
  top: 80%;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}
.lol
{
 border:2px solid black;
    width:30%; 
    margin:1%;
   position: auto;
   align:center;
   }

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>
<script type="text/javascript">

  function validate()
  {
   if(document.myform.fullname.value == "")
   {
   alert("please provide your name!");
   document.myform.fname.focus();
    return false;
   }

   if(document.myform.roll.value=="")
   {
    alert("please provide your ID number!");
    document.myform.roll.focus();
    return false;      
   }
var length=document.myform.roll.value;  
if(length.length!=10){  
  alert("Please enter the correct id no");  
  return false;  
  }  


   if(document.myform.department.value=="")
   {
     alert("please select your department!");
     document.myform.department.focus();
     return false;
   }

   if(document.myform.itemmm.value=="")
   {
     alert("please select the item!");
     document.myform.itemmm.focus();
     return false;
   }

    if( document.myform.quantity.value == "" ||
         isNaN( document.myform.quantity.value ) ||
         document.myform.quantity.value.length <1 )
         {
            alert( "Please select the quantity!." );
            document.myform.quantity.focus() ;
            return false;
         }
         return( true );
      }


</script>
<style>
* {
    box-sizing: border-box;
}

input[type=text], select, textarea {
    
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    resize: vertical;
}

label {
    padding: 10px 12px 12px 0;
    display: inline-block;
    color: blue;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 10px;
    background-color:#808080;
    padding: 50px;
}

.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 25%;
    margin-top: 6px;
}


.row:after {
    content: "";
    display: table;
    clear: both;
}


@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit] {
        width: 50%;
        margin-top:0;
    }
}
body, html {
    height: 100%;
    margin: 0;
}

.bg {
   
    background-image: url("bgstore.jpg");
    height: 100%; 
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    opacity:5em;
}
.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #fdd;
  color: black;
}

.topnav a.active {
  background-color: #ff6990;
  color: white;
}

.topnav .search-items {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 16px;
  border: none;
}

.topnav .search-items button {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 10px;
  background: black;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-items button:hover {
  background: #636;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-items button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 20px;
  }
  .topnav input[type=text] {
    border: 2px solid white;  
  }
}

div.container1 {
    width: 100%;
    border: 1px solid gray;
}

header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}

nav {
    float: left;
    max-width: 160px;
    margin: 0;
    padding:1em;
}

nav ul {
    list-style-type: none;
    padding: 5px;
}
   
nav ul a {
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: black;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>
</head>
<body bgcolor="black">
<h1><img src="logo.svg"/><br />
 <i><font color="black" size="30">ONLINE STORE ROOM MANAGEMENT</font></i></h1>


<div class="topnav">
  <a href="home.php">Home</a>
  <a class="active" href=#Form>Form</a>
  <a href="contact.php">Contact</a>
  <a href="about.php">About</a>
  <a href="complaint.php">complaint</a>
  <div class="search-items">
    <form method="POST"  action="search.php" >
      <input type="text" placeholder="Search.." name="search">
    </form>
  </div>
  <a href="index.php">Logout</a>
</div>
<div class="bg">
<div class="container">
  <form action="form2.php" name="myform" method="POST" onsubmit="return(validate());">
    <div class="row">
      <div class="col-25">
        <label for="fname">Full Name</label>
      </div>
      <div class="col-75">
        <input type="text" id="fname" name="fullname" placeholder="Your name.." pattern="[A-Za-z_ ]*$" />
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="roll">ID</label>
      </div>
      <div class="col-75">
        <input type="text" id="roll" name="roll" placeholder="Enter your id.." />
      </div>
    </div>
     <div class="row">
      <div class="col-25">
        <label for="roll">Email-id</label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="Email" placeholder="Enter your Email-id.." />
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="dept">Select your Department</label>
      </div>
      <div class="col-75">
        <select id="dept" name="department">
	  <optgroup label="school of Engineering">
	<option value="CVE">CVE</option>
	<option value="CSE">CSE</option>
	<option value="ECE">ECE</option>
	<option value="EEE">EEE</option>
	<option value="MEE">MEE</option>
	<option value="PEE">PEE</option>
</optgroup>
<optgroup label="school of Law">
	<option value="B.horns">B.horns</option>
</optgroup>
<optgroup label="school of Management">
	<option value="Business">Business</option>
</optgroup>
</select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="item">select Item Required</label>
      </div>
      <div class="col-75">
        <select id="item" name="itemmm">
	  <optgroup label="Marker">
	<option value="Red Marker">Red Marker</option>
	<option value="Blue Marker">Blue Marker</option>
	<option value="Black Marker">Black Marker</option>
</optgroup>
<optgroup label="Sheets">
	<option value="A4 sheets">A4 Sheets</option>
	<option value="Bond Sheets">Bond Sheets</option>
</optgroup>
<optgroup label="Files">
	<option value="Cardboard File">Cardboard File</option>
	<option value="Stick File">Stick File</option>
</optgroup>
<optgroup label for="cables">
	<option value="HDMI cable">HDMI cable</option>
</optgroup>
</select>
      </div>
    </div>
<div class="row">
      <div class="col-25">
        <label for="quant">Quantity</label>
      </div>
      <div class="col-75">
       <input type="text" id="quant" name="quantity" placeholder="Enter the quantity"/>
       </div>
      </div>

    <div class="row">
      <input type="submit" value="Submit">
    </div>
  </form>
</div>
<?php
session_destroy();
?>
</body>
</html>

