<?php
$name=$_POST['fullname'];
$item=$_POST['itemmm'];
$quantity=$_POST['quantity'];
$department=$_POST['department'];
$id=$_POST['roll'];
$Email=$_POST['Email'];

echo "<h1>Welcome $name to online Storage Management</h1>";
echo "<h3>The Item you have selected is</h3>";

$dbhost='localhost';
$dbuser='root';
$dbpass='123456';
$dbname='store';
$dbc=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) or die ("Error querying database");
$sql="update item set quantity=quantity-'$quantity' where name='$item'";
$res=mysqli_query($dbc,$sql) or die("Sorry");
$sql1="insert into form_request(Fullname,ID,Department,Item_reuqired,quantity) values('$name','$id','$department','$item','$quantity')";
$res1=mysqli_query($dbc,$sql1) or die("i am sorry".mysqli_error($dbc));
?>
<style>
.bg {
   
    background-image: url("opp.jpg");
    height: 98%; 
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    opacity: 1em;
}

table, th, td{
border:1px solid black;
border-collapse: collapse;
}
th, td{
padding:15px;
}
</style>
</head>


<body>
<div class="bg">
<table border=1px>
<tr> 
      <th>Name</th>
<th>Quantity</th>
</tr> 
<tr>
	<td><?php echo $item; ?></td>
	<td><?php echo $quantity; ?></td>

	            </tr>
</table>
<a href="home.php">click here to go to main page</a>
</div>
<?php

mysqli_close($dbc);
session_destroy();
?>
</body>
</html>
