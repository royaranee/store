-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: store
-- ------------------------------------------------------
-- Server version	5.7.21-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `FID` varchar(10) NOT NULL,
  `Username` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  `Email_id` varchar(35) DEFAULT NULL,
  `Department` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES ('CSE0001FAC','John','iamjohn','john@pu.in','Computer_science'),('CSE0002FAC','Ramesh','iamramesh','ramesh@pu.in','Computer_science');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_request`
--

DROP TABLE IF EXISTS `form_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_request` (
  `Slno` int(11) NOT NULL AUTO_INCREMENT,
  `Fullname` varchar(30) DEFAULT NULL,
  `ID` varchar(30) DEFAULT NULL,
  `Department` varchar(20) DEFAULT NULL,
  `Item_reuqired` varchar(30) DEFAULT NULL,
  `quantity` bigint(5) DEFAULT NULL,
  PRIMARY KEY (`Slno`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_request`
--

LOCK TABLES `form_request` WRITE;
/*!40000 ALTER TABLE `form_request` DISABLE KEYS */;
INSERT INTO `form_request` VALUES (1,'ARANEE ROY','2015cse020','CSE','Blue Marker',6),(2,'Roy','2015cse011','CSE','Black Marker',10),(3,'Roy','2015cse011','CSE','Black Marker',10),(4,'Roy','2015cse011','CSE','Black Marker',10),(5,'asdfghjkl','asdfghjkl','CVE','Bond Sheets',20),(6,'123e','asdfg','CVE','A4 sheets',-13),(7,'123e','asdfg','CVE','Red Marker',-13),(8,'asdfghjk','asdfghn','CVE','Red Marker',30),(9,'aqwdfghjsdfghjk','dfgh','CVE','',-1),(10,'chethan R','2015cse020','CVE','',1),(11,'chethan R','asdfg','CVE','',0),(12,'chethan R','2015cse136','ECE','',1),(13,'suhas','2015cse136','CVE','',2),(14,'suhas','2015cse136','CVE','Blue Marker',2),(15,'chethan R','2015cse136','CVE','Red Marker',3),(16,'ARANEE ROY','2015cse020','CSE','Stick File',5),(17,'ARANEE ROY','2015cse020','CSE','Stick File',5),(18,'ARANEE ROY','2015cse020','CSE','Stick File',5);
/*!40000 ALTER TABLE `form_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `name` varchar(30) DEFAULT NULL,
  `quantity` bigint(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES ('red marker',24),('blue marker',24),('black marker',20),('green marker',50),('A4 sheets',413),('cardboard files',200),('hdmi cables',50),('Bond Sheets',480),('Stick File',85);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storemanager_login`
--

DROP TABLE IF EXISTS `storemanager_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storemanager_login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storemanager_login`
--

LOCK TABLES `storemanager_login` WRITE;
/*!40000 ALTER TABLE `storemanager_login` DISABLE KEYS */;
INSERT INTO `storemanager_login` VALUES ('Arun','iamarun');
/*!40000 ALTER TABLE `storemanager_login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-15 10:44:22
