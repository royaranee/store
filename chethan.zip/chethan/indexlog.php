<?php 
    session_start();
	$db=mysqli_connect('localhost','root','123456','store') or die('Unable to connect to MySQL server');
        $form_username=$_POST['username'];
        $_SESSION['Username']=$form_username;
	$form_password=$_POST['password'];
        $table_name=$_POST['roletable'];
        $_SESSION['roletable']=$table_name;

if(!empty($_POST['username']))
{
$query = 1;
$result = mysqli_query($db,"SELECT Username,Password FROM $table_name where Username='$form_username' and Password='$form_password'") or die("sorry");
$row = mysqli_fetch_array($result) or die(header('location:error.php'));
if(!empty($row['Username']) && !empty($row['Password']))
{
if($_SESSION['Username']==$row['Username'] && $form_password == $row['Password'])
{
    if(isset($table_name) && $table_name=='faculty')
        header('location:home.php');
    elseif(isset($table_name) && $table_name=='registrar')
        header('location:registrar.html');
    elseif(isset($table_name) && $table_name=='storemanager_login')
        header('location:manager.php');
}
}
}
?>
