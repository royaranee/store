<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}
.error {color: #FF0000;}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
 text-align:center;
background-image:url("bgcover1.jpg");
background-repeat:no-repeat;
background-size: 1400px 800px;
margin:0;

}
 div.container {
 border:1px solid black;
    width:auto; 
    margin:1%;
    position: auto;
    top: 5%;
    left:30%;
    background-color:white;
  }
  table{
 width:100%;

  border-collapse:collapse;
 background-color:white;
   }
   td,th{
  border:1px solid;
  text-align:center;
  }
  </style>
  </head>
<body>
<div class="container">
<h1>PRODUCT DETAILS</h1>
<form action="remove.php" method="GET">
        
 <?php
 include "connect.php";
$sql="SELECT * FROM items";
 $result=mysqli_query($con,$sql) or die('sorry');
 
?>

<br><br>
	<div id=tables class="table">
		<table>
		<tr>	<th>sl.no</th>
			<th>Image name</th>
			<th>Category</th>
			<th>price</th>
			<th> </th>
		</tr>	
		<?php while($row = mysqli_fetch_array($result)){?>
		<tr>	<?php $_SESSION['filename']=$row['userfile']; ?>
			<td> <?php echo $row['number'] ?> </td>
			<td> <?php echo $row['userfile'] ?></td>
			<td> <?php echo $row['category'] ?></td>
			<td> <?php echo $row['price'] ?></td>
			
			<td> <a href="remove.php?remove_number=<?php echo $row['number'] ?>">DELETE</a> </td>
			
		</tr>
		<?php } ?>
		</table>
		</br></br></br></br></br>
		</br>
	</div>
	</form>
	</div>
	</body>
	</html>
