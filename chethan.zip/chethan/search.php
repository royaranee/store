<html>
<?php
session_start();
?>
<?php
$search=$_POST['search'];
echo "<b>Results found for <br>"."$search"."<br></b>";

$dbc=mysqli_connect('localhost','root','123456','store') or die ("error connecting to the database");


$sql="select * FROM item WHERE name like'%".$search."%' ";
$result=mysqli_query($dbc,$sql) or die("error querying");
?>
<head>
<style>
.bg {
   
    background-image: url("opp.jpg");
    height: 98%; 
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    opacity: 1em;
}

table, th, td{
border:1px solid black;
border-collapse: collapse;
}
th, td{
padding:15px;
}
</style>
</head>


<body>
<div class="bg">
<table border=1px>
<tr> 
      <th>Name</th>
<th>Quantity</th>
</tr> 
<?php
while($row=mysqli_fetch_array($result))
{
?>
<tr>
	<td><?php echo $row['name'] ?></td>
	<td><?php echo $row['quantity'] ?></td>
	            </tr>
<?php
}
?>
</table>
</div>
<?php
mysqli_close($dbc);
?>
</body>
</html>
