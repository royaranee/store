<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "divya";
$dbname = "itpro";
$con=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname)or die('cannot connect to the server'); 
?>
