<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Pretty-Registration-Form.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  text-align:center;
background-image:url("bgstore.jpg");
background-repeat:no-repeat;
background-size: 1400px 1500px;
margin:0;
}

.topnav {
  overflow: hidden;
  background-color: #F00000;
   position: auto;
    width: 100%;
}

.topnav a {
  float: right;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #111111;
  color: white;
}

.topnav a.active {
  background-color: #F00000;
  color: white;
}

.topnav .search-container {
  position:absolute;
    left:11%;
    top:34%;
    width:auto;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;
width:20%;
height:20%;}

/* Slideshow container */
.slideshow-container {
  max-width: 2000px;
  position: auto;
 
  margin: auto;
}
.slideshow-container img {
  max-width:100%;
	width:100%;
	height: 60%;
	position:auto;
	left:0;
	
  }
/* Caption text */
.text {
  color: black;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: black;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 10px;
  width: 10px;
  position:fixed;
  top: 80%;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}
.lol
{
 border:2px solid black;
    width:30%; 
    margin:1%;
   position: auto;
   align:center;
   }

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
</style>
</head>
<body bgcolor="black">

<h1><img src="logo.svg"/><br />
 <i><font color="black" size="30">ONLINE STORE ROOM MANAGEMENT</font></i></h1>
<div class="container" style="float:center;width:30%;">
            <form action="indexlog.php" method="POST">
                <legend><h3>Login </h3></legend>
                
                <fieldset name="Login">
                        <?php    
                            $errors=array(1=>"Invalid username and password, try again.",2=>"Please login to access this area");
                            $error_id=isset($_GET['err'])?(int)$_GET['err']:0;
                            if($error_id==1){
                                echo "$errors[$error_id]";
                            }
                            elseif($error_id==2){
                                echo "$errors[$error_id]";
                            }
                        ?>
                     <select class="form-control input-sm" name="roletable">
                        <optgroup label="Login as:">
                            <option value='faculty'>Faculty</option>
                            <option value='admin_login'>Admin</option>
                            <option value='storemanager_login'>Manager</option>

                        </optgroup>
                    </select><span class="label label-primary">Username </span>
                    <input class="form-control input-sm" type="text" name="username" placeholder="Username" maxlength="11" required><span class="label label-primary">Password </span>
                    <input class="form-control" type="password" name="password" placeholder="Password">
                    <button class="btn btn-default btn-sm" type="submit">Login </button>
                </fieldset>
            </form>
        </div>
       
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>


</body>
</html>
